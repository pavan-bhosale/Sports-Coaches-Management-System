CREATE DATABASE IF NOT EXISTS vava_sports;
USE vava_sports;

-- Batches Table
CREATE TABLE IF NOT EXISTS vsa_batches (
    batch_id INT AUTO_INCREMENT PRIMARY KEY,
    batch_name VARCHAR(100) NOT NULL,
    batch_time VARCHAR(50),
    batch_location VARCHAR(150),
    sport VARCHAR(100) DEFAULT 'Football',
    coach_id INT,
    max_students INT DEFAULT 0,
    current_students INT DEFAULT 0,
    monthly_fee DECIMAL(10,2) DEFAULT 0.00,
    total_payment_due DECIMAL(12,2) DEFAULT 0.00,
    status VARCHAR(20) DEFAULT 'Active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (coach_id) REFERENCES vsa_coaches(coach_id) ON DELETE SET NULL
);

-- Coaches Table
CREATE TABLE IF NOT EXISTS vsa_coaches (
    coach_id INT AUTO_INCREMENT PRIMARY KEY,
    coach_name VARCHAR(100) NOT NULL,
    coach_email VARCHAR(100) UNIQUE NOT NULL,
    coach_phone VARCHAR(20),
    google_id VARCHAR(255) UNIQUE,
    coach_joined_date DATE,
    batch_id INT,
    coach_sport VARCHAR(100),
    max_students INT DEFAULT 0,
    current_students INT DEFAULT 0,
    status VARCHAR(20) DEFAULT 'Active',
    coach_dob DATE,
    coach_license VARCHAR(100),
    emergency_contact_name VARCHAR(100),
    emergency_contact_number VARCHAR(20),
    coach_address VARCHAR(255),
    coach_city VARCHAR(100),
    coach_postal_code VARCHAR(20),
    coach_photo VARCHAR(255),
    FOREIGN KEY (batch_id) REFERENCES vsa_batches(batch_id) ON DELETE SET NULL
);

-- Students Table
CREATE TABLE IF NOT EXISTS vsa_students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    student_email VARCHAR(100) UNIQUE NOT NULL,
    school_name VARCHAR(150),
    student_phone VARCHAR(20),
    google_id VARCHAR(255) UNIQUE,
    address VARCHAR(255),
    date_of_birth DATE,
    joined_date DATE,
    status VARCHAR(20) DEFAULT 'Active',
    parent_name VARCHAR(100) NOT NULL,
    gender VARCHAR(20) NOT NULL,
    blood_group VARCHAR(10) NOT NULL,
    branch_name VARCHAR(100) NOT NULL,
    batch_name VARCHAR(100),
    coach_name VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    postal_code VARCHAR(20) NOT NULL,
    father_contact_number VARCHAR(20) NOT NULL,
    mother_contact_number VARCHAR(20),
    emergency_contact_number VARCHAR(20) NOT NULL,
    whatsapp_number VARCHAR(20) NOT NULL,
    student_photo VARCHAR(255),
    batch_id INT,
    coach_id INT,
    monthly_fee DECIMAL(10,2) DEFAULT 0.00,
    total_fee_due DECIMAL(12,2) DEFAULT 0.00,
    total_fee_paid DECIMAL(12,2) DEFAULT 0.00,
    fee_pending DECIMAL(12,2) DEFAULT 0.00,
    pending_months INT DEFAULT 0,
    payment_status VARCHAR(20) DEFAULT 'Pending',
    student_note TEXT NULL,
    FOREIGN KEY (batch_id) REFERENCES vsa_batches(batch_id) ON DELETE SET NULL,
    FOREIGN KEY (coach_id) REFERENCES vsa_coaches(coach_id) ON DELETE SET NULL
);

-- Verified Users Table
CREATE TABLE IF NOT EXISTS vsa_superadmin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_name VARCHAR(100) NOT NULL,
    admin_email VARCHAR(100) UNIQUE NOT NULL,
    admin_number VARCHAR(15),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Attendance Table
CREATE TABLE IF NOT EXISTS vsa_attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    batch_id INT NOT NULL,
    coach_id INT NOT NULL,
    student_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present','Absent') NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_daily_attendance (batch_id, student_id, attendance_date),
    FOREIGN KEY (batch_id) REFERENCES vsa_batches(batch_id) ON UPDATE CASCADE,
    FOREIGN KEY (coach_id) REFERENCES vsa_coaches(coach_id) ON UPDATE CASCADE,
    FOREIGN KEY (student_id) REFERENCES vsa_students(student_id) ON UPDATE CASCADE
);

-- Student Fees Table
CREATE TABLE IF NOT EXISTS vsa_student_fees (
    fee_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    batch_id INT NOT NULL,
    fee_month DATE NOT NULL,
    due_date DATE NOT NULL,
    fee_amount DECIMAL(10,2) NOT NULL,
    payment_status ENUM('Unpaid','Paid','Overdue','Refunded') NOT NULL DEFAULT 'Unpaid',
    razorpay_order_id VARCHAR(255) NULL,
    razorpay_payment_id VARCHAR(255) NULL,
    payment_method VARCHAR(50) NULL,
    paid_amount DECIMAL(10,2) NULL,
    paid_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_student_month (student_id, fee_month),
    INDEX idx_student_id (student_id),
    INDEX idx_batch_id (batch_id),
    INDEX idx_fee_month (fee_month),
    INDEX idx_payment_status (payment_status)
);

-- Payment Cycle Scheduled Notifications Table
CREATE TABLE IF NOT EXISTS vsa_payment_notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    fee_month DATE NOT NULL,
    scheduled_at DATETIME NOT NULL,
    status ENUM('Scheduled', 'Processing', 'Sent', 'Partial', 'Failed', 'Cancelled') NOT NULL DEFAULT 'Scheduled',
    total_students INT NOT NULL DEFAULT 0,
    sent_count INT NOT NULL DEFAULT 0,
    failed_count INT NOT NULL DEFAULT 0,
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sent_at DATETIME NULL,
    INDEX idx_fee_month (fee_month),
    INDEX idx_due_status (status, scheduled_at)
);

-- Inventory & Equipment Table (Academy-Wide)
CREATE TABLE IF NOT EXISTS vsa_inventory (
    inventory_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(150) NOT NULL UNIQUE,
    total_quantity INT NOT NULL DEFAULT 0,
    allocations JSON NULL,
    stock_history JSON NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Activity & Audit Log Table (Chronological System Actions)
CREATE TABLE IF NOT EXISTS vsa_activity_log (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    actor_id INT NULL,
    actor_name VARCHAR(100) NULL,
    actor_email VARCHAR(100) NULL,
    actor_role VARCHAR(50) NOT NULL DEFAULT 'superadmin',
    module VARCHAR(50) NOT NULL,
    action_type VARCHAR(50) NOT NULL,
    target_type VARCHAR(50) NULL,
    target_id INT NULL,
    target_name VARCHAR(150) NULL,
    description TEXT NOT NULL,
    details JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at DESC),
    INDEX idx_module (module),
    INDEX idx_actor_role (actor_role),
    INDEX idx_action_type (action_type),
    INDEX idx_target (target_type, target_id)
);

