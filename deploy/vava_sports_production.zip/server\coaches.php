<?php
/**
 * VAVA Sports Academy - Coaches API
 * Handles GET (fetch all or by ID), POST (create / upload photo / delete photo / assign batch), PUT (update), DELETE (delete coach)
 */

require_once 'auth_helper.php';
applyCorsHeaders('GET, POST, PUT, DELETE, OPTIONS');

require_once 'db_connect.php';
require_once 'activity_logger.php';

// Enforce session authentication for all requests
$currentUser = requireAuthSession($pdo);

$method = $_SERVER['REQUEST_METHOD'];

// Mutations require Super Admin (or coach managing own photo)
if ($method === 'PUT' || $method === 'DELETE') {
    if ($currentUser['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied. Only Super Admin can modify or delete coaches.']);
        exit;
    }
}

// ── GET: fetch coaches ─────────────────────────────────────────────────────
if ($method === 'GET') {
    $id = intval($_GET['id'] ?? 0);
    try {
        if ($id > 0) {
            $stmt = $pdo->prepare('
                SELECT c.*, 
                       GROUP_CONCAT(DISTINCT b.batch_name ORDER BY b.batch_name ASC SEPARATOR ", ") AS batch_name,
                       GROUP_CONCAT(DISTINCT b.batch_id ORDER BY b.batch_name ASC SEPARATOR ",") AS batch_ids,
                       GROUP_CONCAT(DISTINCT b.sport SEPARATOR ", ") AS batch_sport
                FROM vsa_coaches c
                LEFT JOIN vsa_batches b ON (b.coach_id = c.coach_id OR c.batch_id = b.batch_id)
                WHERE c.coach_id = ?
                GROUP BY c.coach_id
            ');
            $stmt->execute([$id]);
            $coach = $stmt->fetch();
            if (!$coach) {
                http_response_code(404);
                echo json_encode(['error' => 'Coach not found.']);
                exit;
            }
            echo json_encode(['success' => true, 'coach' => $coach]);
        } else {
            $stmt = $pdo->query('
                SELECT c.*, 
                       GROUP_CONCAT(DISTINCT b.batch_name ORDER BY b.batch_name ASC SEPARATOR ", ") AS batch_name,
                       GROUP_CONCAT(DISTINCT b.batch_id ORDER BY b.batch_name ASC SEPARATOR ",") AS batch_ids,
                       GROUP_CONCAT(DISTINCT b.sport SEPARATOR ", ") AS batch_sport
                FROM vsa_coaches c
                LEFT JOIN vsa_batches b ON (b.coach_id = c.coach_id OR c.batch_id = b.batch_id)
                GROUP BY c.coach_id
                ORDER BY c.coach_id DESC
            ');
            $coaches = $stmt->fetchAll();
            echo json_encode(['success' => true, 'coaches' => $coaches]);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// ── POST: register a coach OR handle photo / batch actions ────────────────
if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';

    // Check permissions
    if ($action === 'upload_photo' || $action === 'delete_photo') {
        $targetCoachId = intval($input['coach_id'] ?? 0);
        if ($currentUser['role'] !== 'admin' && ($currentUser['role'] !== 'coach' || intval($currentUser['coach_id'] ?? 0) !== $targetCoachId)) {
            http_response_code(403);
            echo json_encode(['error' => 'Access denied. You cannot modify photos for this coach.']);
            exit;
        }
    } else {
        // Registering a new coach is strictly Super Admin only
        if ($currentUser['role'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Access denied. Only Super Admin can register new coaches.']);
            exit;
        }
    }

    // Handle Upload Photo
    if ($action === 'upload_photo') {
        $coach_id = intval($input['coach_id'] ?? 0);
        $image_data = $input['image_data'] ?? '';

        if (!$coach_id || !$image_data) {
            http_response_code(400);
            echo json_encode(['error' => 'coach_id and image_data are required.']);
            exit;
        }

        $uploadDir = __DIR__ . '/../uploads/coaches/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if (preg_match('/^data:image\/(\w+);base64,/', $image_data, $type)) {
            $image_data = substr($image_data, strpos($image_data, ',') + 1);
            $ext = strtolower($type[1]);
            if ($ext === 'jpeg') $ext = 'jpg';
        } else {
            $ext = 'jpg';
        }

        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            $ext = 'jpg';
        }

        $image_data = base64_decode($image_data);
        if ($image_data === false) {
            http_response_code(400);
            echo json_encode(['error' => 'Base64 image decoding failed.']);
            exit;
        }

        if (strlen($image_data) > 5 * 1024 * 1024) {
            http_response_code(400);
            echo json_encode(['error' => 'Image file exceeds maximum allowed size of 5 MB.']);
            exit;
        }

        $filename = 'coach_' . $coach_id . '_' . time() . '.' . $ext;
        $filepath = $uploadDir . $filename;
        $relativePath = 'uploads/coaches/' . $filename;

        try {
            $stmtOld = $pdo->prepare('SELECT coach_photo FROM vsa_coaches WHERE coach_id = ?');
            $stmtOld->execute([$coach_id]);
            $oldCoach = $stmtOld->fetch();
            if ($oldCoach && !empty($oldCoach['coach_photo'])) {
                $oldFile = __DIR__ . '/../' . $oldCoach['coach_photo'];
                if (file_exists($oldFile)) {
                    @unlink($oldFile);
                }
            }
        } catch (Exception $e) {}

        if (file_put_contents($filepath, $image_data) === false) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to save image file on server.']);
            exit;
        }

        try {
            $stmt = $pdo->prepare('UPDATE vsa_coaches SET coach_photo = ? WHERE coach_id = ?');
            $stmt->execute([$relativePath, $coach_id]);
            echo json_encode(['success' => true, 'coach_photo' => $relativePath]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to update database: ' . $e->getMessage()]);
        }
        exit;
    }

    // Handle Delete Photo
    if ($action === 'delete_photo') {
        $coach_id = intval($input['coach_id'] ?? 0);
        if (!$coach_id) {
            http_response_code(400);
            echo json_encode(['error' => 'coach_id is required.']);
            exit;
        }

        try {
            $stmtOld = $pdo->prepare('SELECT coach_photo FROM vsa_coaches WHERE coach_id = ?');
            $stmtOld->execute([$coach_id]);
            $coach = $stmtOld->fetch();
            if ($coach && !empty($coach['coach_photo'])) {
                $oldFile = __DIR__ . '/../' . $coach['coach_photo'];
                if (file_exists($oldFile)) {
                    @unlink($oldFile);
                }
            }
            $stmt = $pdo->prepare('UPDATE vsa_coaches SET coach_photo = NULL WHERE coach_id = ?');
            $stmt->execute([$coach_id]);
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to delete photo: ' . $e->getMessage()]);
        }
        exit;
    }

    // Handle Regular Coach Registration
    $coach_name               = trim($input['coach_name']               ?? '');
    $coach_email              = trim($input['coach_email']              ?? '');
    $coach_phone              = trim($input['coach_phone']              ?? '');
    $coach_dob                = trim($input['coach_dob']                ?? '');
    $coach_joined_date        = trim($input['coach_joined_date']        ?? '');
    $coach_license            = trim($input['coach_license']            ?? '');
    $coach_address            = trim($input['coach_address']            ?? '');
    $coach_city               = trim($input['coach_city']               ?? '');
    $coach_postal_code        = trim($input['coach_postal_code']        ?? '');
    $emergency_contact_name   = trim($input['emergency_contact_name']   ?? '');
    $emergency_contact_number = trim($input['emergency_contact_number'] ?? '');
    $coach_sport              = trim($input['coach_sport']              ?? '');
    $status                   = trim($input['status']                   ?? 'Active');
    $batch_id                 = intval($input['batch_id']               ?? 0);

    if (!$coach_name || !$coach_email || !$coach_phone) {
        http_response_code(400);
        echo json_encode(['error' => 'Coach Name, Email, and Contact Number are required.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO vsa_coaches (
                coach_name, coach_email, coach_phone, coach_dob, coach_joined_date,
                coach_license, coach_address, coach_city, coach_postal_code,
                emergency_contact_name, emergency_contact_number, coach_sport, status, batch_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $coach_name, $coach_email, $coach_phone,
            $coach_dob ?: null, $coach_joined_date ?: null,
            $coach_license, $coach_address, $coach_city, $coach_postal_code,
            $emergency_contact_name, $emergency_contact_number, $coach_sport, $status,
            $batch_id > 0 ? $batch_id : null
        ]);
        $newId = $pdo->lastInsertId();

        recordActivity($pdo, 'COACH', 'Created', 'Coach', $newId, $coach_name, "Registered coach {$coach_name} (Email: {$coach_email})", [
            'coach_id'    => $newId,
            'coach_name'  => $coach_name,
            'coach_email' => $coach_email,
            'sport'       => $coach_sport,
            'status'      => $status,
            'batch_id'    => $batch_id > 0 ? $batch_id : null
        ], $input);

        echo json_encode([
            'success' => true,
            'coach_id' => $newId
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save coach: ' . $e->getMessage()]);
    }
    exit;
}

// ── PUT: update an existing coach ──────────────────────────────────────────
if ($method === 'PUT') {
    $input = json_decode(file_get_contents('php://input'), true);

    $coach_id                 = intval($input['coach_id']               ?? 0);
    $coach_name               = trim($input['coach_name']               ?? '');
    $coach_email              = trim($input['coach_email']              ?? '');
    $coach_phone              = trim($input['coach_phone']              ?? '');
    $coach_dob                = trim($input['coach_dob']                ?? '');
    $coach_joined_date        = trim($input['coach_joined_date']        ?? '');
    $coach_license            = trim($input['coach_license']            ?? '');
    $coach_address            = trim($input['coach_address']            ?? '');
    $coach_city               = trim($input['coach_city']               ?? '');
    $coach_postal_code        = trim($input['coach_postal_code']        ?? '');
    $emergency_contact_name   = trim($input['emergency_contact_name']   ?? '');
    $emergency_contact_number = trim($input['emergency_contact_number'] ?? '');
    $coach_sport              = trim($input['coach_sport']              ?? '');
    $status                   = trim($input['status']                   ?? 'Active');
    $batch_id                 = intval($input['batch_id']               ?? 0);

    if (!$coach_id || !$coach_name || !$coach_email || !$coach_phone) {
        http_response_code(400);
        echo json_encode(['error' => 'coach_id, Name, Email, and Phone are required.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare(
            'UPDATE vsa_coaches SET
                coach_name = ?, coach_email = ?, coach_phone = ?, coach_dob = ?, coach_joined_date = ?,
                coach_license = ?, coach_address = ?, coach_city = ?, coach_postal_code = ?,
                emergency_contact_name = ?, emergency_contact_number = ?, coach_sport = ?, status = ?,
                batch_id = ?
             WHERE coach_id = ?'
        );
        $stmt->execute([
            $coach_name, $coach_email, $coach_phone,
            $coach_dob ?: null, $coach_joined_date ?: null,
            $coach_license, $coach_address, $coach_city, $coach_postal_code,
            $emergency_contact_name, $emergency_contact_number, $coach_sport, $status,
            $batch_id > 0 ? $batch_id : null,
            $coach_id
        ]);

        recordActivity($pdo, 'COACH', 'Updated', 'Coach', $coach_id, $coach_name, "Updated coach profile for {$coach_name} (ID: #{$coach_id})", [
            'coach_id'    => $coach_id,
            'coach_name'  => $coach_name,
            'coach_email' => $coach_email,
            'sport'       => $coach_sport,
            'status'      => $status,
            'batch_id'    => $batch_id > 0 ? $batch_id : null
        ], $input);

        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update coach: ' . $e->getMessage()]);
    }
    exit;
}

// ── DELETE: delete coach by id ─────────────────────────────────────────────
if ($method === 'DELETE') {
    $input = json_decode(file_get_contents('php://input'), true);
    $coach_id = intval($input['coach_id'] ?? 0);

    if (!$coach_id) {
        http_response_code(400);
        echo json_encode(['error' => 'coach_id is required.']);
        exit;
    }

    try {
        $stmtOld = $pdo->prepare('SELECT coach_id, coach_name, coach_email, coach_photo FROM vsa_coaches WHERE coach_id = ?');
        $stmtOld->execute([$coach_id]);
        $coach = $stmtOld->fetch();
        if (!$coach) {
            http_response_code(404);
            echo json_encode(['error' => 'Coach not found.']);
            exit;
        }

        if (!empty($coach['coach_photo'])) {
            $oldFile = __DIR__ . '/../' . $coach['coach_photo'];
            if (file_exists($oldFile)) {
                @unlink($oldFile);
            }
        }

        // Unlink batches assigned to this coach
        $stmtBatch = $pdo->prepare('UPDATE vsa_batches SET coach_id = NULL WHERE coach_id = ?');
        $stmtBatch->execute([$coach_id]);

        // Unlink students assigned to this coach
        $stmtStud = $pdo->prepare('UPDATE vsa_students SET coach_id = NULL WHERE coach_id = ?');
        $stmtStud->execute([$coach_id]);

        // Clean up role mapping in vsa_user_roles to prevent orphaned mappings
        $stmtRole = $pdo->prepare("DELETE FROM vsa_user_roles WHERE role = 'coach' AND entity_id = ?");
        $stmtRole->execute([$coach_id]);

        $stmt = $pdo->prepare('DELETE FROM vsa_coaches WHERE coach_id = ?');
        $stmt->execute([$coach_id]);

        $coachTitle = "Coach #{$coach_id} ({$coach['coach_name']})";
        recordActivity($pdo, 'COACH', 'Deleted', 'Coach', $coach_id, $coachTitle, "Deleted {$coachTitle}", $coach, $input);

        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        http_response_code(500);
        $errMsg = function_exists('formatSafeErrorMessage') ? formatSafeErrorMessage($e, 'Failed to delete coach.') : $e->getMessage();
        echo json_encode(['error' => $errMsg]);
    }
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
?>
