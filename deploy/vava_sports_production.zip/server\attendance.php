<?php
/**
 * VAVA Sports Academy - Attendance API
 * Handles GET & POST with role restriction (Coach-only) and assigned batch filtering.
 */

require_once 'auth_helper.php';
applyCorsHeaders('GET, POST, DELETE, OPTIONS');

require_once 'db_connect.php';
require_once 'activity_logger.php';

$method = $_SERVER['REQUEST_METHOD'];

/**
 * Helper function to authenticate role and resolve logged-in user info (Coach or Superadmin)
 * Authoritative source of truth is the server-side PHP session.
 */
function resolveAuthenticatedUser($pdo, $input = []) {
    $user = getAuthenticatedSessionUser($pdo);
    if (!$user) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Authentication required. Please log in.']);
        exit;
    }

    if ($user['role'] === 'student') {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Access denied. The Attendance module is accessible to coaches and superadmin only.']);
        exit;
    }

    if ($user['role'] === 'coach') {
        $coach = $user['coach'] ?? null;
        if (!$coach) {
            http_response_code(403);
            echo json_encode(['success' => false, 'error' => 'Coach authorization failed or coach record not found.']);
            exit;
        }
        return ['role' => 'coach', 'coach' => $coach];
    }

    if ($user['role'] === 'admin' || $user['role'] === 'superadmin') {
        return ['role' => 'superadmin', 'admin' => $user['admin']];
    }

    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Access denied. The Attendance module is accessible to coaches and superadmin only.']);
    exit;
}

// ── GET REQUESTS ─────────────────────────────────────────────────────────────
if ($method === 'GET') {
    $auth = resolveAuthenticatedUser($pdo);
    $isSuperadmin = ($auth['role'] === 'superadmin');
    $coach = $auth['coach'] ?? null;
    $coach_batch_id = intval($coach['batch_id'] ?? 0);
    $coach_id = intval($coach['coach_id'] ?? 0);
    $action = $_GET['action'] ?? '';

    // Action: Fetch students for a specific batch & attendance date
    if ($action === 'get_students') {
        $batch_id = intval($_GET['batch_id'] ?? 0);
        $attendance_date = trim($_GET['attendance_date'] ?? '');

        if (!$batch_id || !$attendance_date) {
            http_response_code(400);
            echo json_encode(['error' => 'batch_id and attendance_date are required.']);
            exit;
        }

        // Access Control: Coach can only access their assigned batches
        $isCoachBatch = ($batch_id === $coach_batch_id);
        if (!$isCoachBatch && $coach_id > 0) {
            $chk = $pdo->prepare('SELECT batch_id FROM vsa_batches WHERE batch_id = ? AND coach_id = ?');
            $chk->execute([$batch_id, $coach_id]);
            if ($chk->fetch()) {
                $isCoachBatch = true;
            }
        }
        if (!$isSuperadmin && !$isCoachBatch) {
            http_response_code(403);
            echo json_encode(['error' => 'Access denied. You can only view attendance for your assigned batch.']);
            exit;
        }

        try {
            $stmt = $pdo->prepare('
                SELECT 
                    s.student_id, 
                    s.student_name, 
                    COALESCE(a.status, "Absent") AS status
                FROM vsa_students s
                CROSS JOIN vsa_batches b ON b.batch_id = ?
                LEFT JOIN vsa_attendance a 
                    ON s.student_id = a.student_id 
                   AND a.batch_id = b.batch_id 
                   AND a.attendance_date = ?
                WHERE (s.batch_id = b.batch_id OR LOWER(TRIM(s.batch_name)) = LOWER(TRIM(b.batch_name)))
                ORDER BY s.student_name ASC
            ');
            $stmt->execute([$batch_id, $attendance_date]);
            $students = $stmt->fetchAll();

            echo json_encode([
                'success' => true,
                'is_superadmin' => $isSuperadmin,
                'read_only' => $isSuperadmin,
                'students' => $students
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Action: Fetch list of active batches for dropdown
    if ($action === 'get_batches') {
        try {
            if ($isSuperadmin) {
                $stmt = $pdo->query('SELECT batch_id, batch_name FROM vsa_batches ORDER BY batch_name ASC');
                $batches = $stmt->fetchAll();
            } else {
                $stmt = $pdo->prepare('
                    SELECT DISTINCT batch_id, batch_name 
                    FROM vsa_batches 
                    WHERE coach_id = ? OR batch_id = ? 
                    ORDER BY batch_name ASC
                ');
                $stmt->execute([$coach_id, $coach_batch_id]);
                $batches = $stmt->fetchAll();
            }
            echo json_encode(['success' => true, 'batches' => $batches]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Action: Fetch students with real attendance statistics
    if ($action === 'get_coach_students_attendance') {
        try {
            if ($isSuperadmin) {
                // Superadmin sees all students across all batches with batch and coach names
                $stmt = $pdo->prepare('
                    SELECT 
                        s.student_id,
                        s.student_name,
                        s.city,
                        s.student_photo,
                        COALESCE(NULLIF(s.student_phone, ""), NULLIF(s.father_contact_number, ""), s.emergency_contact_number, "") AS student_phone,
                        COALESCE(s.batch_id, b.batch_id, 0) AS batch_id,
                        COALESCE(NULLIF(s.batch_name, ""), b.batch_name, "Unassigned") AS batch_name,
                        COALESCE(NULLIF(s.coach_name, ""), c.coach_name, cb.coach_name, "Unassigned") AS coach_name,
                        COUNT(a.attendance_id) AS total_records,
                        SUM(CASE WHEN a.status = "Present" THEN 1 ELSE 0 END) AS present_count
                    FROM vsa_students s
                    LEFT JOIN vsa_batches b ON s.batch_id = b.batch_id
                    LEFT JOIN vsa_coaches c ON s.coach_id = c.coach_id
                    LEFT JOIN vsa_coaches cb ON b.batch_id = cb.batch_id
                    LEFT JOIN vsa_attendance a ON s.student_id = a.student_id
                    GROUP BY s.student_id, s.student_name, s.city, s.student_photo, student_phone, batch_id, batch_name, coach_name
                    ORDER BY s.student_name ASC
                ');
                $stmt->execute();
            } else {
                // Coach sees students in assigned batch
                $stmt = $pdo->prepare('
                    SELECT 
                        s.student_id,
                        s.student_name,
                        s.city,
                        s.student_photo,
                        COALESCE(NULLIF(s.student_phone, ""), NULLIF(s.father_contact_number, ""), s.emergency_contact_number, "") AS student_phone,
                        b.batch_id,
                        COALESCE(NULLIF(s.batch_name, ""), b.batch_name, "Unassigned") AS batch_name,
                        COUNT(a.attendance_id) AS total_records,
                        SUM(CASE WHEN a.status = "Present" THEN 1 ELSE 0 END) AS present_count
                    FROM vsa_students s
                    CROSS JOIN vsa_batches b ON b.batch_id = ?
                    LEFT JOIN vsa_attendance a ON s.student_id = a.student_id AND a.batch_id = b.batch_id
                    WHERE (s.batch_id = b.batch_id OR LOWER(TRIM(s.batch_name)) = LOWER(TRIM(b.batch_name)))
                    GROUP BY s.student_id, s.student_name, s.city, s.student_photo, student_phone, b.batch_id, s.batch_name, b.batch_name
                    ORDER BY s.student_name ASC
                ');
                $stmt->execute([$coach_batch_id]);
            }
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Format counts as integers for safety and calculate percentage
            $formatted = array_map(function($st) {
                $st['total_records'] = intval($st['total_records'] ?? 0);
                $st['present_count'] = intval($st['present_count'] ?? 0);
                $st['percentage'] = $st['total_records'] > 0 
                    ? round(($st['present_count'] / $st['total_records']) * 100) 
                    : 0;
                return $st;
            }, $students);

            $response = [
                'success' => true,
                'is_superadmin' => $isSuperadmin,
                'students' => $formatted
            ];

            if (!$isSuperadmin && $coach) {
                $response['coach_info'] = [
                    'coach_id' => intval($coach['coach_id']),
                    'coach_name' => $coach['coach_name'],
                    'batch_id' => intval($coach['batch_id']),
                    'batch_name' => $coach['batch_name']
                ];
            }

            echo json_encode($response);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Action: Fetch full attendance history for a single student
    if ($action === 'get_student_attendance_history') {
        $student_id = intval($_GET['student_id'] ?? 0);
        if (!$student_id) {
            http_response_code(400);
            echo json_encode(['error' => 'student_id is required.']);
            exit;
        }

        try {
            if ($isSuperadmin) {
                $checkStmt = $pdo->prepare('
                    SELECT 
                        s.student_id, 
                        s.student_name, 
                        s.city, 
                        s.student_photo,
                        COALESCE(NULLIF(s.student_phone, ""), NULLIF(s.father_contact_number, ""), s.emergency_contact_number, "") AS student_phone,
                        COALESCE(NULLIF(s.batch_name, ""), b.batch_name, "Unassigned") AS batch_name,
                        COALESCE(NULLIF(s.coach_name, ""), c.coach_name, cb.coach_name, "Unassigned") AS coach_name
                    FROM vsa_students s
                    LEFT JOIN vsa_batches b ON s.batch_id = b.batch_id
                    LEFT JOIN vsa_coaches c ON s.coach_id = c.coach_id
                    LEFT JOIN vsa_coaches cb ON b.batch_id = cb.batch_id
                    WHERE s.student_id = ?
                    LIMIT 1
                ');
                $checkStmt->execute([$student_id]);
                $student = $checkStmt->fetch(PDO::FETCH_ASSOC);

                if (!$student) {
                    http_response_code(404);
                    echo json_encode(['error' => 'Student not found.']);
                    exit;
                }

                $histStmt = $pdo->prepare('
                    SELECT 
                        attendance_date, 
                        status 
                    FROM vsa_attendance 
                    WHERE student_id = ? 
                    ORDER BY attendance_date DESC
                ');
                $histStmt->execute([$student_id]);
                $history = $histStmt->fetchAll(PDO::FETCH_ASSOC);
            } else {
                // Verify student belongs to coach\'s batch
                $checkStmt = $pdo->prepare('
                    SELECT 
                        s.student_id, 
                        s.student_name, 
                        s.city, 
                        s.student_photo,
                        COALESCE(NULLIF(s.student_phone, ""), NULLIF(s.father_contact_number, ""), s.emergency_contact_number, "") AS student_phone,
                        COALESCE(NULLIF(s.batch_name, ""), b.batch_name, "Unassigned") AS batch_name
                    FROM vsa_students s
                    CROSS JOIN vsa_batches b ON b.batch_id = ?
                    WHERE s.student_id = ? AND (s.batch_id = b.batch_id OR LOWER(TRIM(s.batch_name)) = LOWER(TRIM(b.batch_name)))
                    LIMIT 1
                ');
                $checkStmt->execute([$coach_batch_id, $student_id]);
                $student = $checkStmt->fetch(PDO::FETCH_ASSOC);

                if (!$student) {
                    http_response_code(403);
                    echo json_encode(['error' => 'Access denied or student not found in your assigned batch.']);
                    exit;
                }

                // Fetch records sorted Latest -> Oldest
                $histStmt = $pdo->prepare('
                    SELECT 
                        attendance_date, 
                        status 
                    FROM vsa_attendance 
                    WHERE student_id = ? AND batch_id = ? 
                    ORDER BY attendance_date DESC
                ');
                $histStmt->execute([$student_id, $coach_batch_id]);
                $history = $histStmt->fetchAll(PDO::FETCH_ASSOC);
            }

            $presentCount = 0;
            $totalCount = count($history);
            foreach ($history as $h) {
                if ($h['status'] === 'Present') {
                    $presentCount++;
                }
            }
            $percentage = $totalCount > 0 ? round(($presentCount / $totalCount) * 100) : 0;

            echo json_encode([
                'success' => true,
                'student' => $student,
                'stats' => [
                    'present_count' => $presentCount,
                    'total_records' => $totalCount,
                    'percentage' => $percentage
                ],
                'history' => $history
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Default GET: Fetch Attendance sheets
    try {
        if ($isSuperadmin) {
            // Superadmin sees attendance sheets from ALL batches
            $stmt = $pdo->query('
                SELECT 
                    a.batch_id,
                    a.attendance_date,
                    b.batch_name,
                    COALESCE(c.coach_name, cb.coach_name, "Unassigned") AS coach_name,
                    a.coach_id,
                    (
                        SELECT COUNT(*) 
                        FROM vsa_students s 
                        WHERE s.batch_id = b.batch_id OR LOWER(TRIM(s.batch_name)) = LOWER(TRIM(b.batch_name))
                    ) AS total_batch_students,
                    COUNT(a.attendance_id) AS sheet_records_count,
                    SUM(CASE WHEN a.status = "Present" THEN 1 ELSE 0 END) AS present_count
                FROM vsa_attendance a
                INNER JOIN vsa_batches b ON a.batch_id = b.batch_id
                LEFT JOIN vsa_coaches c ON a.coach_id = c.coach_id
                LEFT JOIN vsa_coaches cb ON b.batch_id = cb.batch_id
                GROUP BY a.batch_id, a.attendance_date, b.batch_name, coach_name, a.coach_id
                ORDER BY a.attendance_date DESC, b.batch_name ASC
            ');
            $sheets = $stmt->fetchAll();

            echo json_encode([
                'success' => true,
                'is_superadmin' => true,
                'sheets' => $sheets
            ]);
        } else {
            // Coach sees sheets ONLY for assigned batch_id
            $stmt = $pdo->prepare('
                SELECT 
                    a.batch_id,
                    a.attendance_date,
                    b.batch_name,
                    COALESCE(c.coach_name, "Unassigned") AS coach_name,
                    a.coach_id,
                    (
                        SELECT COUNT(*) 
                        FROM vsa_students s 
                        WHERE s.batch_id = b.batch_id OR LOWER(TRIM(s.batch_name)) = LOWER(TRIM(b.batch_name))
                    ) AS total_batch_students,
                    COUNT(a.attendance_id) AS sheet_records_count,
                    SUM(CASE WHEN a.status = "Present" THEN 1 ELSE 0 END) AS present_count
                FROM vsa_attendance a
                INNER JOIN vsa_batches b ON a.batch_id = b.batch_id
                LEFT JOIN vsa_coaches c ON a.coach_id = c.coach_id
                WHERE a.batch_id = ?
                GROUP BY a.batch_id, a.attendance_date, b.batch_name, coach_name, a.coach_id
                ORDER BY a.attendance_date DESC, b.batch_name ASC
            ');
            $stmt->execute([$coach_batch_id]);
            $sheets = $stmt->fetchAll();

            echo json_encode([
                'success' => true,
                'is_superadmin' => false,
                'coach_info' => [
                    'coach_id' => intval($coach['coach_id']),
                    'coach_name' => $coach['coach_name'],
                    'batch_id' => intval($coach['batch_id']),
                    'batch_name' => $coach['batch_name']
                ],
                'sheets' => $sheets
            ]);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
    exit;
}

// ── POST REQUESTS ────────────────────────────────────────────────────────────
if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $auth = resolveAuthenticatedUser($pdo, $input);
    $isSuperadmin = ($auth['role'] === 'superadmin');
    $coach = $auth['coach'] ?? null;
    $coach_batch_id = intval($coach['batch_id'] ?? 0);
    $coach_id = intval($coach['coach_id'] ?? 0);
    $action = $input['action'] ?? '';

    // Action: Create a new attendance sheet
    if ($action === 'create_sheet') {
        if ($isSuperadmin) {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied. Superadmin has read-only access for creating attendance sheets.']);
            exit;
        }

        // Automatically enforce coach's assigned batch_id
        $batch_id = intval($input['batch_id'] ?? 0);
        if (!$batch_id) {
            $batch_id = $coach_batch_id;
        }
        $attendance_date = trim($input['attendance_date'] ?? '');

        $isCoachBatch = ($batch_id === $coach_batch_id);
        if (!$isCoachBatch && $coach_id > 0) {
            $chk = $pdo->prepare('SELECT batch_id FROM vsa_batches WHERE batch_id = ? AND coach_id = ?');
            $chk->execute([$batch_id, $coach_id]);
            if ($chk->fetch()) {
                $isCoachBatch = true;
            }
        }

        if (!$batch_id || !$isCoachBatch) {
            http_response_code(400);
            echo json_encode(['error' => 'Coach has no access to this batch.']);
            exit;
        }

        if (!$attendance_date) {
            http_response_code(400);
            echo json_encode(['error' => 'Please select an attendance date.']);
            exit;
        }

        try {
            // Check if attendance already exists for this batch + date
            $checkStmt = $pdo->prepare('SELECT COUNT(*) FROM vsa_attendance WHERE batch_id = ? AND attendance_date = ?');
            $checkStmt->execute([$batch_id, $attendance_date]);
            if ($checkStmt->fetchColumn() > 0) {
                http_response_code(400);
                echo json_encode(['error' => 'Attendance for your assigned batch and date already exists.']);
                exit;
            }

            // Fetch students belonging to the assigned batch
            $studStmt = $pdo->prepare('
                SELECT s.student_id 
                FROM vsa_students s
                CROSS JOIN vsa_batches b ON b.batch_id = ?
                WHERE (s.batch_id = b.batch_id OR LOWER(TRIM(s.batch_name)) = LOWER(TRIM(b.batch_name)))
            ');
            $studStmt->execute([$batch_id]);
            $students = $studStmt->fetchAll();

            if (empty($students)) {
                http_response_code(400);
                echo json_encode(['error' => 'No students found in your assigned batch. Please add students to the batch first.']);
                exit;
            }

            // Insert initial default attendance records (status: Absent)
            $insertStmt = $pdo->prepare('
                INSERT INTO vsa_attendance (batch_id, coach_id, student_id, attendance_date, status)
                VALUES (?, ?, ?, ?, ?)
            ');

            foreach ($students as $student) {
                $insertStmt->execute([$batch_id, $coach_id, $student['student_id'], $attendance_date, 'Absent']);
            }

            // Fetch batch name and assigned coach name
            $batchStmt = $pdo->prepare('
                SELECT b.batch_id, b.batch_name, b.coach_id, c.coach_name 
                FROM vsa_batches b 
                LEFT JOIN vsa_coaches c ON b.coach_id = c.coach_id 
                WHERE b.batch_id = ?
            ');
            $batchStmt->execute([$batch_id]);
            $batchRow = $batchStmt->fetch();
            $batchName = $batchRow['batch_name'] ?? ($coach['batch_name'] ?? '');
            $coachName = $batchRow['coach_name'] ?? ($coach['coach_name'] ?? '');

            $numStudents = count($students);
            $desc = "Created attendance sheet for Batch #{$batch_id} ({$batchName}) on {$attendance_date} ({$numStudents} students)";
            recordActivity($pdo, 'ATTENDANCE', 'Created', 'Attendance', $batch_id, "Batch #{$batch_id} ({$batchName})", $desc, [
                'batch_id'        => $batch_id,
                'batch_name'      => $batchName,
                'coach_name'      => $coachName,
                'attendance_date' => $attendance_date,
                'student_count'   => $numStudents
            ], $input);

            echo json_encode([
                'success' => true,
                'message' => 'Attendance sheet created successfully.',
                'batch_id' => $batch_id,
                'batch_name' => $batchName,
                'coach_name' => $coachName,
                'attendance_date' => $attendance_date
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    // Action: Save / Update attendance for students in an open sheet
    if ($action === 'save_attendance') {
        if ($isSuperadmin) {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied. Superadmin has read-only access for marking attendance.']);
            exit;
        }

        $batch_id = intval($input['batch_id'] ?? 0);
        if (!$batch_id) {
            $batch_id = $coach_batch_id;
        }
        $attendance_date = trim($input['attendance_date'] ?? '');
        $records = $input['records'] ?? [];

        $isCoachBatch = ($batch_id === $coach_batch_id);
        if (!$isCoachBatch && $coach_id > 0) {
            $chk = $pdo->prepare('SELECT batch_id FROM vsa_batches WHERE batch_id = ? AND coach_id = ?');
            $chk->execute([$batch_id, $coach_id]);
            if ($chk->fetch()) {
                $isCoachBatch = true;
            }
        }

        if (!$isCoachBatch) {
            http_response_code(403);
            echo json_encode(['error' => 'Access denied. You can only save attendance for your assigned batch.']);
            exit;
        }

        if (!$batch_id || !$attendance_date || !is_array($records)) {
            http_response_code(400);
            echo json_encode(['error' => 'batch_id, attendance_date, and records array are required.']);
            exit;
        }

        try {
            $pdo->beginTransaction();

            $upsertStmt = $pdo->prepare('
                INSERT INTO vsa_attendance (batch_id, coach_id, student_id, attendance_date, status)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    status = VALUES(status), 
                    coach_id = VALUES(coach_id)
            ');

            $presentCount = 0;
            $absentCount = 0;
            foreach ($records as $rec) {
                $student_id = intval($rec['student_id'] ?? 0);
                $status = ($rec['status'] === 'Present') ? 'Present' : 'Absent';
                if ($status === 'Present') {
                    $presentCount++;
                } else {
                    $absentCount++;
                }
                if ($student_id > 0) {
                    $upsertStmt->execute([$batch_id, $coach_id, $student_id, $attendance_date, $status]);
                }
            }

            $pdo->commit();

            $bStmt = $pdo->prepare('SELECT batch_name FROM vsa_batches WHERE batch_id = ?');
            $bStmt->execute([$batch_id]);
            $batchName = $bStmt->fetchColumn() ?: "Batch #{$batch_id}";
            $desc = "Saved attendance for Batch #{$batch_id} ({$batchName}) on {$attendance_date} ({$presentCount} present, {$absentCount} absent)";
            recordActivity($pdo, 'ATTENDANCE', 'Recorded', 'Attendance', $batch_id, "Batch #{$batch_id} ({$batchName})", $desc, [
                'batch_id'        => $batch_id,
                'batch_name'      => $batchName,
                'attendance_date' => $attendance_date,
                'present_count'   => $presentCount,
                'absent_count'    => $absentCount,
                'total_marked'    => count($records)
            ], $input);

            echo json_encode([
                'success' => true,
                'message' => 'Attendance records saved successfully.'
            ]);
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            http_response_code(500);
            $errMsg = function_exists('formatSafeErrorMessage') ? formatSafeErrorMessage($e, 'Database error occurred saving attendance.') : $e->getMessage();
            echo json_encode(['error' => $errMsg]);
        }
        exit;
    }

    // Action: Delete an entire attendance sheet
    if ($action === 'delete_sheet') {
        $batch_id = intval($input['batch_id'] ?? 0);
        if (!$batch_id && !$isSuperadmin) {
            $batch_id = $coach_batch_id;
        }
        $attendance_date = trim($input['attendance_date'] ?? '');

        if (!$isSuperadmin && $batch_id !== $coach_batch_id) {
            http_response_code(403);
            echo json_encode(['error' => 'Access denied. You can only delete attendance for your assigned batch.']);
            exit;
        }

        if (!$batch_id || !$attendance_date) {
            http_response_code(400);
            echo json_encode(['error' => 'batch_id and attendance_date are required.']);
            exit;
        }

        try {
            $bStmt = $pdo->prepare('SELECT batch_name FROM vsa_batches WHERE batch_id = ?');
            $bStmt->execute([$batch_id]);
            $batchName = $bStmt->fetchColumn() ?: "Batch #{$batch_id}";

            $delStmt = $pdo->prepare('DELETE FROM vsa_attendance WHERE batch_id = ? AND attendance_date = ?');
            $delStmt->execute([$batch_id, $attendance_date]);

            $desc = "Deleted attendance sheet for Batch #{$batch_id} ({$batchName}) on {$attendance_date}";
            recordActivity($pdo, 'ATTENDANCE', 'Deleted', 'Attendance', $batch_id, "Batch #{$batch_id} ({$batchName})", $desc, [
                'batch_id'        => $batch_id,
                'batch_name'      => $batchName,
                'attendance_date' => $attendance_date
            ], $input);

            echo json_encode([
                'success' => true,
                'message' => 'Attendance sheet deleted successfully.'
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    http_response_code(400);
    echo json_encode(['error' => 'Invalid action.']);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed.']);
?>
